<?php

// require_once "bots/bot-1.php";
// require_once "bots/bot-2.php";
// require_once "bots/bot-3.php";
// require_once "bots/bot-4.php";
// require_once "bots/bot-5.php";
// require_once "bots/bot-6.php";
// require_once "bots/bot-7.php";
// require_once "bots/bot-8.php";
// require_once "bots/p-block.php";

?>
