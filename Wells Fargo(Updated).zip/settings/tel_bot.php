<?php 
	$token = "5524603160:AAGxYOfxjWt90_pR5Q5VDgLv54AxzZepBgA";//Your telegram bot token
	$chat_id="1719057870"; // Your telegram chat ID
	
?>